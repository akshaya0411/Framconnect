package com.app.services;


import com.app.dto.UserDto;
import com.app.entity.User;

public interface UserService {
 User findByUsername(String username);

 User save(UserDto userDto);

}

package com.app.sellingcart.controller;



import com.app.sellingcart.entity.CartItem;
import com.app.sellingcart.repository.CartItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cart")
public class CartController {
    @Autowired
    private CartItemRepository cartItemRepository;

    @PostMapping("/save")
    public String saveCartItems(@RequestBody List<CartItem> cartItems) {
        cartItemRepository.saveAll(cartItems);
        return "Cart items saved successfully!";
    }
}

